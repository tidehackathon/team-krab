--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE iodashboard;
--
-- Name: iodashboard; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE iodashboard WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\connect iodashboard

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: capabilities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.capabilities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


SET default_table_access_method = heap;

--
-- Name: capabilities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capabilities (
    id integer DEFAULT nextval('public.capabilities_id_seq'::regclass) NOT NULL,
    nation_id integer NOT NULL,
    name character varying(255),
    maturity character varying(50)
);


--
-- Name: capability_operational_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capability_operational_domains (
    capability_id integer NOT NULL,
    operational_domain_id integer NOT NULL
);


--
-- Name: capability_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capability_tasks (
    capability_id integer NOT NULL,
    task_id integer NOT NULL
);


--
-- Name: capability_warfarelevels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capability_warfarelevels (
    capability_id integer NOT NULL,
    warfarelevel_id integer NOT NULL
);


--
-- Name: focus_areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.focus_areas (
    id integer NOT NULL,
    name character varying NOT NULL,
    is_operational_domain smallint DEFAULT 0
);


--
-- Name: focus_areas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.focus_areas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: focus_areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.focus_areas_id_seq OWNED BY public.focus_areas.id;


--
-- Name: issue_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.issue_categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text
);


--
-- Name: issue_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.issue_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: issue_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.issue_categories_id_seq OWNED BY public.issue_categories.id;


--
-- Name: nations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nations (
    id integer DEFAULT nextval('public.nations_id_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: objectives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.objectives (
    id integer NOT NULL,
    focus_area_id integer NOT NULL,
    name character varying(200) NOT NULL,
    title character varying(255),
    exercise_cycle character varying(20) NOT NULL
);


--
-- Name: objectives_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.objectives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: objectives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.objectives_id_seq OWNED BY public.objectives.id;


--
-- Name: operational_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_domains (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: operational_domains_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.operational_domains_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: operational_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.operational_domains_id_seq OWNED BY public.operational_domains.id;


--
-- Name: standards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.standards (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    title character(500),
    type character varying(50)
);


--
-- Name: standards_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.standards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: standards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.standards_id_seq OWNED BY public.standards.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: test_objectives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_objectives (
    testcase_id integer NOT NULL,
    objective_id integer NOT NULL,
    exercise_cycle character varying(50)
);


--
-- Name: test_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_participants (
    capability_id integer NOT NULL,
    testcase_id integer NOT NULL,
    exercise_cycle character varying(50) NOT NULL,
    participant_role character varying(50) NOT NULL,
    participant_result character varying(50)
);


--
-- Name: testcase_issue_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testcase_issue_categories (
    testcase_id integer NOT NULL,
    issue_category_id integer NOT NULL
);


--
-- Name: testcase_standards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testcase_standards (
    testcase_id integer NOT NULL,
    standard_id integer NOT NULL
);


--
-- Name: testcases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testcases (
    id integer NOT NULL,
    tc_number character varying(100),
    exercise_cycle character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    overall_result character varying(50),
    io_shortfall_ind boolean
);


--
-- Name: testcases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.testcases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: testcases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.testcases_id_seq OWNED BY public.testcases.id;


--
-- Name: warfare_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warfare_levels (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: warfare_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.warfare_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warfare_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.warfare_levels_id_seq OWNED BY public.warfare_levels.id;


--
-- Name: focus_areas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.focus_areas ALTER COLUMN id SET DEFAULT nextval('public.focus_areas_id_seq'::regclass);


--
-- Name: issue_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_categories ALTER COLUMN id SET DEFAULT nextval('public.issue_categories_id_seq'::regclass);


--
-- Name: objectives id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.objectives ALTER COLUMN id SET DEFAULT nextval('public.objectives_id_seq'::regclass);


--
-- Name: operational_domains id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_domains ALTER COLUMN id SET DEFAULT nextval('public.operational_domains_id_seq'::regclass);


--
-- Name: standards id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.standards ALTER COLUMN id SET DEFAULT nextval('public.standards_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: testcases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testcases ALTER COLUMN id SET DEFAULT nextval('public.testcases_id_seq'::regclass);


--
-- Name: warfare_levels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warfare_levels ALTER COLUMN id SET DEFAULT nextval('public.warfare_levels_id_seq'::regclass);


--
-- Name: capabilities capabilities_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capabilities
    ADD CONSTRAINT capabilities_pk PRIMARY KEY (id);


--
-- Name: capability_operational_domains capability_operational_domain_capability_id_operational_dom_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_operational_domains
    ADD CONSTRAINT capability_operational_domain_capability_id_operational_dom_key UNIQUE (capability_id, operational_domain_id) INCLUDE (capability_id, operational_domain_id);


--
-- Name: capability_tasks capability_tasks_capability_id_task_id_capability_id1_task__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_tasks
    ADD CONSTRAINT capability_tasks_capability_id_task_id_capability_id1_task__key UNIQUE (capability_id, task_id) INCLUDE (capability_id, task_id);


--
-- Name: capability_warfarelevels capability_warfarelevels_capability_id_warfarelevel_id_capa_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capability_warfarelevels
    ADD CONSTRAINT capability_warfarelevels_capability_id_warfarelevel_id_capa_key UNIQUE (capability_id, warfarelevel_id) INCLUDE (capability_id, warfarelevel_id);


--
-- Name: focus_areas focus_areas_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.focus_areas
    ADD CONSTRAINT focus_areas_pk PRIMARY KEY (id);


--
-- Name: issue_categories issue_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.issue_categories
    ADD CONSTRAINT issue_categories_pkey PRIMARY KEY (id);


--
-- Name: nations nations_fk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nations
    ADD CONSTRAINT nations_fk PRIMARY KEY (id);


--
-- Name: objectives objective_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT objective_pk PRIMARY KEY (id);


--
-- Name: operational_domains operational_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_domains
    ADD CONSTRAINT operational_domains_pkey PRIMARY KEY (id);


--
-- Name: standards standards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.standards
    ADD CONSTRAINT standards_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: testcases testcases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testcases
    ADD CONSTRAINT testcases_pkey PRIMARY KEY (id);


--
-- Name: warfare_levels warfare_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warfare_levels
    ADD CONSTRAINT warfare_levels_pkey PRIMARY KEY (id);


--
-- Name: test_participants capability_testcases_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_participants
    ADD CONSTRAINT capability_testcases_fk FOREIGN KEY (capability_id) REFERENCES public.capabilities(id) ON DELETE CASCADE NOT VALID;


--
-- Name: objectives fa_objective_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.objectives
    ADD CONSTRAINT fa_objective_fk FOREIGN KEY (focus_area_id) REFERENCES public.focus_areas(id) ON DELETE CASCADE NOT VALID;


--
-- Name: testcase_issue_categories issue_testcases_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testcase_issue_categories
    ADD CONSTRAINT issue_testcases_fk FOREIGN KEY (issue_category_id) REFERENCES public.issue_categories(id) NOT VALID;


--
-- Name: capabilities nation_capabilities_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capabilities
    ADD CONSTRAINT nation_capabilities_fk FOREIGN KEY (nation_id) REFERENCES public.nations(id) ON DELETE CASCADE NOT VALID;


--
-- Name: testcase_standards standards_tc_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testcase_standards
    ADD CONSTRAINT standards_tc_fk FOREIGN KEY (standard_id) REFERENCES public.standards(id) ON DELETE CASCADE NOT VALID;


--
-- Name: testcase_standards tc_standards_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testcase_standards
    ADD CONSTRAINT tc_standards_fk FOREIGN KEY (testcase_id) REFERENCES public.testcases(id) NOT VALID;


--
-- Name: test_objectives test_objectives_objective_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_objectives
    ADD CONSTRAINT test_objectives_objective_id_fkey FOREIGN KEY (objective_id) REFERENCES public.objectives(id) ON DELETE CASCADE NOT VALID;


--
-- Name: test_objectives test_objectives_testcase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_objectives
    ADD CONSTRAINT test_objectives_testcase_id_fkey FOREIGN KEY (testcase_id) REFERENCES public.testcases(id) ON DELETE CASCADE NOT VALID;


--
-- Name: testcase_issue_categories testcase_issue_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testcase_issue_categories
    ADD CONSTRAINT testcase_issue_fk FOREIGN KEY (testcase_id) REFERENCES public.testcases(id) NOT VALID;


--
-- Name: test_participants testcases_capability_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_participants
    ADD CONSTRAINT testcases_capability_fk FOREIGN KEY (testcase_id) REFERENCES public.testcases(id) ON DELETE CASCADE NOT VALID;


--
-- PostgreSQL database dump complete
--

